# Hoboken Restaurant
* Switch to `HobokenRestaurant`: Input Code below:

 `mongoimport --db final --collection restaurants --drop --file originaldata.json --jsonArray`

* Use command below to reprocessd data

`node processdata.js`
